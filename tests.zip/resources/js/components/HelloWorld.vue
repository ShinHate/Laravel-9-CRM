<template>
    <h1>{{ greeting }}</h1>
</template>
<script>
export default {
    setup: () => ({
        greeting: 'Hello World from Vue 3!'
    })
}
</script>
