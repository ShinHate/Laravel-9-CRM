<!DOCTYPE html>
<html>
<head>

</head>
<body class="antialiased">
<div id="app">
    <div class="relative flex items-top justify-center min-h-screen bg-gray-100 sm:items-center py-4 sm:pt-0">
        <hello-world/>
    </div>
</div>
<script src="{{ asset('js/app.js') }}"></script>
</body>
</html>
